jQuery(document).ready(function($){

if (typeof cf7_logic != 'undefined')  {


$(".wpcf7 input[type='reset']").closest('form').on('reset', function(event) {
  setTimeout(function() {
    cf7_logic_check();
  }, 1);
});

  cf7_logic_check();
  $(".wpcf7 input, .wpcf7 select").change(function(event) {
    cf7_logic_check();
  });
  $( "input" ).on( "cf7_logic", function( event ) {
    cf7_logic_check();
  });
  function cf7_logic_check(){
    $.each( cf7_logic, function( key, value ) { 
          var check = cf7_logic_check_condition(value.when,value.condition);
          console.log(check);
           cf7_show_hide(check,value.type,value.then);
    })
  }

  function cf7_show_hide(check, type ,then) {

     if( check ) {
        
          $.each( then, function( key, value ) { 
              if( type == "show" ) {
                  $("#"+value).removeClass('cf7-logic-hidden');
              }else{
                  $("#"+value).addClass('cf7-logic-hidden');
              }
          })
      }else {
        $.each( then, function( key, value ) { 
              if( type == "show" ) {
                  $("#"+value).addClass('cf7-logic-hidden');
              }else{
                  $("#"+value).removeClass('cf7-logic-hidden');
              }
          })
      }
       var hide_name = [];
      $( ".cf7-group.cf7-logic-hidden input,.cf7-group.cf7-logic-hidden textarea" ).each(function( index ) {
          hide_name.push($(this).attr("name"));
      })
      $("input[name=_cf_logic]").val(hide_name.join("|"));
  }

  function cf7_logic_check_condition( when , condition) {
    
    if( when == "one" ) { 
        var check = false;
        $.each( condition, function( key, value ) {  

            var name = value.name;
            var equals = value.equals;
            var content = value.value;

            var type = $("input[name="+name+"]").attr("type");

            if( type === undefined ) {
              var type = $("input[name='"+name+"[]']").attr("type");
            }

            if( type =="checkbox" ){
              $("input[name='"+name+"[]']:checked, input[name='"+name+"']:checked").each(function () {
                   var vl = $(this).val();
                   if( equals == "1" ) {
                      if( content == vl ){
                        check = true;
                        return;
                      }
                  }else if( equals == "3"  ) {
                    content = Number(content);
                    vl = Number(vl);
                      if( content < vl ){
                        check = true;
                        return;
                      }
                  }else if( equals == "4"  ) {
                    content = Number(content);
                    vl = Number(vl);
                    if( content <= vl ){
                        check = true;
                        return;
                      }
                  }else if( equals == "5"  ) {
                    content = Number(content);
                    vl = Number(vl);
                    if( content > vl ){
                        check = true;
                        return;
                      }
                  }else if( equals == "6"  ) {
                    content = Number(content);
                    vl = Number(vl);
                    if( content >= vl ){
                        check = true;
                        return;
                      }
                  }
                  else{
                      if( content != vl ){
                        check = true;
                        return;
                      }
                  }
              });
              
            }else if( type == "radio"){
              var vl = $("input[name='"+name+"']:checked").val();

            }else if( type === undefined ){
              var vl = $("select[name="+name+"]").val();  
            }else{
              var vl = $("input[name="+name+"]").val();
            }

            if( equals == "1" ) {
                if( content == vl ){
                  check = true;
                  return;
                }
            }else if( equals == "3"  ) {
                  content = Number(content);
                    vl = Number(vl);
                  if( content < vl ){
                    check = true;
                    return;
                  }
              }else if( equals == "4"  ) {
                content = Number(content);
                    vl = Number(vl);
                if( content <= vl ){
                    check = true;
                    return;
                  }
              }else if( equals == "5"  ) {
                content = Number(content);
                    vl = Number(vl);
                if( content > vl ){
                    check = true;
                    return;
                  }
              }else if( equals == "6"  ) {
                content = Number(content);
                    vl = Number(vl);
                if( content >= vl ){
                    check = true;
                    return;
                  }
              }

            else{
                if( content != vl ){
                  check = true;
                  return;
                }
            }
      })
    } else {
        var check = true;
        $.each( condition, function( key, value ) {  
            var name = value.name;
            var equals = value.equals;
            var content = value.value;
            //var vl = $("input[name="+name+"]").val();


             var type = $("input[name="+name+"]").attr("type");
            if( type === undefined ) {
              var type = $("input[name='"+name+"[]']").attr("type");
            }
            
            if( type =="checkbox" ){
              var checkbox = false;
              var checkbox_false = false;
              $("input[name='"+name+"[]']:checked, input[name='"+name+"']:checked").each(function () {
                   var vl = $(this).val();
                   console.log(equals);
                   if( equals == "1" ) {
                      if( content == vl ){
                        checkbox = true;
                        console.log(111111);
                        return;
                      }
                  }else if( equals == "3"  ) {
                    content = Number(content);
                    vl = Number(vl);
                      if( content < vl ){
                        checkbox = true;
                        return;
                      }
                  }else if( equals == "4"  ) {
                    content = Number(content);
                    vl = Number(vl);
                    if( content <= vl ){
                        checkbox = true;
                        return;
                      }
                  }else if( equals == "5"  ) {
                    content = Number(content);
                    vl = Number(vl);
                    if( content > vl ){
                        checkbox = true;
                        return;
                      }
                  }else if( equals == "6"  ) {
                    content = Number(content);
                    vl = Number(vl);
                    if( content >= vl ){
                        checkbox = true;
                        return;
                      }
                  }else{
                      if( content == vl ){
                          checkbox_false = true;
                      }
                  }
              });


            }else if( type == "radio"){
              var vl = $("input[name='"+name+"']:checked").val();

            }else if( type === undefined ){
              var vl = $("select[name="+name+"]").val();  
            }else{
              var vl = $("input[name="+name+"]").val();
            }
            


            if( equals == "1" ) {
                if( type == "checkbox") {
                      if( checkbox == false) {
                          check =false;
                          return;
                        }
                  }else{
                    if( content == vl ){    
                      }else{
                        check =false;
                          return;
                      }
                  }
            }else if( equals == "3"  ) {
                 if( type == "checkbox") {
                      if( checkbox == false) {
                          check =false;
                          return;
                        }
                  }else{
                    content = Number(content);
                    vl = Number(vl);
                    if( content < vl ){    
                      }else{
                        check =false;
                          return;
                      }
                  }
              }else if( equals == "4"  ) {
                if( type == "checkbox") {
                      if( checkbox == false) {
                          check =false;
                          return;
                        }
                  }else{
                    content = Number(content);
                    vl = Number(vl);
                    if( content <= vl ){    
                      }else{
                        check =false;
                          return;
                      }
                  }
              }else if( equals == "5"  ) {
                if( type == "checkbox") {
                      if( checkbox == false) {
                          check =false;
                          return;
                        }
                  }else{
                    content = Number(content);
                    vl = Number(vl);
                    if( content > vl ){    
                      }else{
                        check =false;
                          return;
                      }
                  }
              }else if( equals == "6"  ) {
               
                if( type == "checkbox") {
                      if( checkbox == false) {
                          check =false;
                          return;
                        }
                  }else{
                    content = Number(content);
                    vl = Number(vl);
                    if( content >= vl ){   

                      }else{
                        check =false;
                          return;
                      }
                  }
              }else{
                if( type == "checkbox") {
                      if( checkbox_false == true) {
                          check =false;
                          return;
                        }
                  }else{
                     if( content != vl ){
                
                      }else{
                        check =false;
                          return;
                        
                }
                  }

               
            }
        })
        
    }
    return check;
  }
}
})
