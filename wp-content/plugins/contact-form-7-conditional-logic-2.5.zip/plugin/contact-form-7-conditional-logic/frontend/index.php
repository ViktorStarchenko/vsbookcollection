<?php
if ( !function_exists( 'add_action' ) ) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}
class cf7_logic_frontend {
    function __construct(){
        add_action("wp_enqueue_scripts",array($this,"add_lib"));
        add_filter('wpcf7_form_response_output', array($this,'add_settings'),99999,4);

    }
     function add_settings($output, $class, $content,$data){
       // $settings = cf7_settings_calculator::get_settings($data->id);
       $datas = get_post_meta($data->id(),'cf7_logic',true);

        $output1 ="";
        if( is_array($datas) ) {
          $output1 .= '<script type="text/javascript">';
          $output1 .= 'var cf7_logic = '. json_encode($datas) .';';
          $output1 .= '</script>';
        }
        return $output.$output1;
    }

  
     /*
    * Add js and css
    */
     function add_lib(){
        wp_enqueue_script("contact-form-7-logic",CT7_LOGIC_PLUGIN_URL."frontend/js/conditional-logic.js",array('jquery'),time(),true);
        wp_enqueue_style("contact-form-7-logic",CT7_LOGIC_PLUGIN_URL."frontend/css/conditional-logic.css");
    }
   
}
new cf7_logic_frontend;