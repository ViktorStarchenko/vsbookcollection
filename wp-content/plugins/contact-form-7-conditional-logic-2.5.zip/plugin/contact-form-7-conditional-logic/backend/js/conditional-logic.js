jQuery(document).ready(function($){
   if (_wpcf7 == null) { var _wpcf7 = wpcf7};

   $("body").on("click",".cf7-logic-add-equals",function(e){
   		var data = $("#data-li-name").html();
   		var rand_id = Math.floor(Math.random() * 10000);
         var main_id = $(this).closest('li').find('.cf7_logic_main_id').val();
         data = data.replace(/jjj/g,rand_id);
         data = data.replace(/cf7_logic_temp/g,'cf7_logic['+main_id+']');
   		$(this).closest('div').find('ul').append('<li>'+data+"</li>");
   		return false;
   })

   $("body").on("click",".cf7-remove-condition",function(e){
   		if( confirm("Are you sure you want to remove this condition?") ) {
   			$(this).closest('li').remove();
   		}
   		return false;
   })
   $("body").on("click","#cf7-logic-add",function(e){
      var data = $("#data-li-condition").html();
      var rand_id = Math.floor(Math.random() * 10000);
      data = data.replace(/cf7_logic_temp/g,'cf7_logic['+rand_id+']');
      data = data.replace(/datamain/g,rand_id);
      $(".cf7-logic-main").append('<li>'+data+"</li>");
      return false;
   })
   $("body").on("click",".cf7-logic-remove-equals",function(e){
      $(this).closest('li').remove();
      return false;
   })
   var cf7_compose = _wpcf7.taggen.compose;
   _wpcf7.taggen.compose = function(tagType, $form)
    {

       $('#tag-generator-panel-group-style-hidden').val($('#tag-generator-panel-group-style').val());
        var ref = cf7_compose.apply(this, arguments);
        if (tagType== 'group') ref += " [/group]";
        return ref;
    };
    $(".cf7_import_demo_conditional_logic").click(function(event) {
      /* Act on the event */
      event.preventDefault();
      if (confirm('It will overwrite the current content! Do you want to do it?')) {
          $("#wpcf7-form").val(cf7_logic.data);
          $(".cf7-logic-main").html(cf7_logic.settings);
          $("#contact-form-editor-tabs li").first().find('a').click();
      } 
    });
})