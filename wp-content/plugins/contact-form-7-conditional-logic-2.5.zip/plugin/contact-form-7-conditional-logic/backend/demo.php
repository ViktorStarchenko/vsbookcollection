<?php
if( ! class_exists( "cf7_import_demo" ) ) {
	class cf7_import_demo{
		function __construct(){
			add_filter("wpcf7_editor_panels",array($this,"custom_form"));
		}
		function custom_form($panels){
			$panels["form-panel-import-demo"] = array(
					'title' => __( 'Import Demo', 'contact-form-7' ),
					'callback' => array($this,"page" ));

			return $panels;
		}
		function page($post){
			$content ='<table class="form-table">';
			echo apply_filters("contact_form_7_import",$content,$post);
			echo '</table>';
		}
	}
	new cf7_import_demo();
}
add_filter("contact_form_7_import","contact_form_7_import_conditional_logic");
function contact_form_7_import_conditional_logic($content){
	$new_content ='<tr>
					<th scope="row">
						<label for="">
							Conditional Logic Plugin
						</label>
					</th>
					<td>
						<a class="button cf7_import_demo_conditional_logic" href="#">Click import content demo</a>
					</td>
				</tr>';
	return $content . $new_content;
}
function cf7_get_content_demo_settings(){
	return '<ul class="cf7-logic-main">
                <li>
            <input type="hidden" class="cf7_logic_main_id" value="1">
            <div class="cf7-loic-grounp-head">
                <div class="cf7-logic-name">Show or hide or Disable</div>
                <select name="cf7_logic[1][type]">
                    <option value="show">Show</option>
                    <option value="hide">Hide</option>
                </select>
                Groups: 
                                     <label for=""><input checked="" value="group-1" type="checkbox" name="cf7_logic[1][then][]"> group-1</label>
                                     <label for=""><input value="group-2" type="checkbox" name="cf7_logic[1][then][]"> group-2</label>
                                     <label for=""><input value="group-3" type="checkbox" name="cf7_logic[1][then][]"> group-3</label>
                             </div>
            <div class="cf7-logic-when">
                <div class="cf7-logic-name">When to Trigger</div>
                <select name="cf7_logic[1][when]">
                    <option value="all">All</option>
                    <option value="one">one</option>
                </select>
            </div>
            <div class="cf7-inner-container">
                <div class="cf7-logic-name">Condition</div>
                <ul>
                                        <li class="data-li-name">If 
                        <select name="cf7_logic[1][condition][1][name]">
                                                        <option selected="selected" value="menu-827">menu-827</option>
                                                         <option value="field-1">field-1</option>
                                                         <option value="field-2">field-2</option>
                                                         <option value="field-3">field-3</option>
                                                         <option value="field-4">field-4</option>
                                                         <option value="field-5">field-5</option>
                                                         <option value="field-6">field-6</option>
                                                         <option value="field-7">field-7</option>
                                                     </select>
                        <select name="cf7_logic[1][condition][1][equals]">
                            <option value="1">==</option>
                            <option value="2">!=</option>
                            <option value="3">&gt;</option>
                            <option value="4">&gt;=</option>
                            <option value="5">&lt;</option>
                            <option value="6">&lt;=</option>
                        </select>
                        <input type="text" name="cf7_logic[1][condition][1][value]" value="Group 1">
                        <a href="#" class="button cf7-logic-remove-equals" title=""><span class="dashicons dashicons-no-alt"></span></a>
                    </li>
                                </ul>
                <a href="#" class="button button-small cf7-logic-add-equals" title="">Add Condition</a>
            </div>
             <a href="#" class="button button-small cf7-remove-condition" title="">Remove Condition</a>
        </li>
            <li>
            <input type="hidden" class="cf7_logic_main_id" value="2">
            <div class="cf7-loic-grounp-head">
                <div class="cf7-logic-name">Show or hide or Disable</div>
                <select name="cf7_logic[2][type]">
                    <option value="show">Show</option>
                    <option value="hide">Hide</option>
                </select>
                Groups: 
                                     <label for=""><input value="group-1" type="checkbox" name="cf7_logic[2][then][]"> group-1</label>
                                     <label for=""><input checked="" value="group-2" type="checkbox" name="cf7_logic[2][then][]"> group-2</label>
                                     <label for=""><input value="group-3" type="checkbox" name="cf7_logic[2][then][]"> group-3</label>
                             </div>
            <div class="cf7-logic-when">
                <div class="cf7-logic-name">When to Trigger</div>
                <select name="cf7_logic[2][when]">
                    <option value="all">All</option>
                    <option value="one">one</option>
                </select>
            </div>
            <div class="cf7-inner-container">
                <div class="cf7-logic-name">Condition</div>
                <ul>
                                        <li class="data-li-name">If 
                        <select name="cf7_logic[2][condition][1][name]">
                                                        <option selected="selected" value="menu-827">menu-827</option>
                                                         <option value="field-1">field-1</option>
                                                         <option value="field-2">field-2</option>
                                                         <option value="field-3">field-3</option>
                                                         <option value="field-4">field-4</option>
                                                         <option value="field-5">field-5</option>
                                                         <option value="field-6">field-6</option>
                                                         <option value="field-7">field-7</option>
                                                     </select>
                        <select name="cf7_logic[2][condition][1][equals]">
                            <option value="1">==</option>
                            <option value="2">!=</option>
                            <option value="3">&gt;</option>
                            <option value="4">&gt;=</option>
                            <option value="5">&lt;</option>
                            <option value="6">&lt;=</option>
                        </select>
                        <input type="text" name="cf7_logic[2][condition][1][value]" value="Group 2">
                        <a href="#" class="button cf7-logic-remove-equals" title=""><span class="dashicons dashicons-no-alt"></span></a>
                    </li>
                                </ul>
                <a href="#" class="button button-small cf7-logic-add-equals" title="">Add Condition</a>
            </div>
             <a href="#" class="button button-small cf7-remove-condition" title="">Remove Condition</a>
        </li>
            <li>
            <input type="hidden" class="cf7_logic_main_id" value="3">
            <div class="cf7-loic-grounp-head">
                <div class="cf7-logic-name">Show or hide or Disable</div>
                <select name="cf7_logic[3][type]">
                    <option value="show">Show</option>
                    <option value="hide">Hide</option>
                </select>
                Groups: 
                                     <label for=""><input value="group-1" type="checkbox" name="cf7_logic[3][then][]"> group-1</label>
                                     <label for=""><input value="group-2" type="checkbox" name="cf7_logic[3][then][]"> group-2</label>
                                     <label for=""><input checked="" value="group-3" type="checkbox" name="cf7_logic[3][then][]"> group-3</label>
                             </div>
            <div class="cf7-logic-when">
                <div class="cf7-logic-name">When to Trigger</div>
                <select name="cf7_logic[3][when]">
                    <option value="all">All</option>
                    <option value="one">one</option>
                </select>
            </div>
            <div class="cf7-inner-container">
                <div class="cf7-logic-name">Condition</div>
                <ul>
                                        <li class="data-li-name">If 
                        <select name="cf7_logic[3][condition][1][name]">
                                                        <option selected="selected" value="menu-827">menu-827</option>
                                                         <option value="field-1">field-1</option>
                                                         <option value="field-2">field-2</option>
                                                         <option value="field-3">field-3</option>
                                                         <option value="field-4">field-4</option>
                                                         <option value="field-5">field-5</option>
                                                         <option value="field-6">field-6</option>
                                                         <option value="field-7">field-7</option>
                                                     </select>
                        <select name="cf7_logic[3][condition][1][equals]">
                            <option value="1">==</option>
                            <option value="2">!=</option>
                            <option value="3">&gt;</option>
                            <option value="4">&gt;=</option>
                            <option value="5">&lt;</option>
                            <option value="6">&lt;=</option>
                        </select>
                        <input type="text" name="cf7_logic[3][condition][1][value]" value="Group 3">
                        <a href="#" class="button cf7-logic-remove-equals" title=""><span class="dashicons dashicons-no-alt"></span></a>
                    </li>
                                </ul>
                <a href="#" class="button button-small cf7-logic-add-equals" title="">Add Condition</a>
            </div>
             <a href="#" class="button button-small cf7-remove-condition" title="">Remove Condition</a>
        </li>
            
    </ul>';
}